// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef TURTLESIM__SRV__KILL_HPP_
#define TURTLESIM__SRV__KILL_HPP_

#include "turtlesim/srv/detail/kill__struct.hpp"
#include "turtlesim/srv/detail/kill__builder.hpp"
#include "turtlesim/srv/detail/kill__traits.hpp"
#include "turtlesim/srv/detail/kill__type_support.hpp"

#endif  // TURTLESIM__SRV__KILL_HPP_
