extern int test_LCD_Output16BitWord(void);
